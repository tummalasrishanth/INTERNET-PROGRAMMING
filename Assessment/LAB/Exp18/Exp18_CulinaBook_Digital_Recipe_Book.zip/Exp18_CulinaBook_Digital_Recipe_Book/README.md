# Experiment 18: CulinaBook Digital Recipe Book Platform (CulinaBook)

## 3 Ways to Open & Run (Zero Blank Pages)
1. **Instant Browser Open (No Setup Needed):** Double-click `index.html` (or `frontend/index.html`) directly in your browser. It renders the complete light-mode interface with auto-rotating hero images immediately.
2. **Full-Stack Server Mode (`http://localhost:5018`):**
   ```bash
   cd backend
   npm install
   npm start
   ```
   Open `http://localhost:5018` in your browser — Express serves both the frontend UI and REST/Socket.io APIs on a single port!
3. **MySQL Database Persistence:**
   ```bash
   mysql -u root -p < database/schema.sql
   ```
