const express = require('express');
const http = require('http');
const path = require('path');
const cors = require('cors');
const { Server } = require('socket.io');
require('dotenv').config();

const authRoutes = require('./routes/authRoutes');
const apiRoutes = require('./routes/apiRoutes');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

app.use(cors());
app.use(express.json());
app.use((req, _res, next) => {
  req.io = io;
  next();
});

app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', experiment: 18, project: 'CulinaBook Digital Recipe Book Platform' });
});

app.use('/api/auth', authRoutes);
app.use('/api', apiRoutes);

// Serve the full web application directly from Express so http://localhost:5018 opens the full UI immediately
app.use(express.static(path.join(__dirname, '..')));
app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, '..', 'index.html'));
});

io.on('connection', (socket) => {
  console.log('Client connected:', socket.id);
});

const PORT = process.env.PORT || 5018;
server.listen(PORT, () => {
  console.log(`[CulinaBook] Full-Stack App running on http://localhost:${PORT}`);
});
